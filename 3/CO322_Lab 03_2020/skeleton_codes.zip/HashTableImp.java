/*********************************************
 
	* CO322: Data structures and algorithms
 
	* Implementation of the hashTable
 *********************************************/
import java.lang.*;

class HashTableImp implements HashTable //this class implements HashTable interface. This hashtable use hash division
{

    //LinkedList<Integer>[] vertex = new LinkedList[5];

	/* Put your code here */
	protected LinkedList [] BucketSet;		//to store a table of Buckets need a array of linked lists
	protected int Buckets;					//number of Buckets

	public HashTableImp(int Buckets) 		//initializing a hashtable
		{	
			 this.Buckets = Buckets;		
			 BucketSet = new LinkedList[Buckets];

			 for (int i = 0;i < Buckets; i++) 	//initialize buckets
				 {
				 	BucketSet[i] = new LinkedList();
				 }
			 
		// create a open hash table with given number of Buckets 
	    
		}


	
	public int hashFunction(String key) 	//generate bucket in hashtable for a key value
	    { 
	        int index = (int)(asciValue(key)%Buckets); 	//index = k % no_of_buckets
	        return Math.abs(index); 	//returns absolute value
	    }     

	  



	public double asciValue(String key)		//generate key for an string
	{
			long bucketIndex = 0;	//use long because could exceed integer range

			char arr[] =  key.toCharArray();	//breakdown string in to characters

			int len = arr.length;	//get word length

	        for (int i = 0; i < len ; i++) 
			{
				bucketIndex = bucketIndex + (int)arr[i]*((long)Math.pow(128, len -1 -i));	//key = 128^0*x1 + 128^2*x2+ ..... 
			}

			return bucketIndex;	//return key
	}
	

	public void insert(String key)	//inserts an string into hashtable
		{	
			int bucketIndex = hashFunction(key); 	//1st get bucket
			LinkedList.insertToBucket(BucketSet[bucketIndex], key);		//then insert to the correct linked list
		
		}

    
	/* given the key return the number of times it was inserted 
     
	 * to the table 
     
	*/
  
	public int search(String key)	
	{	
		int bucketIndex = hashFunction(key); 	//get bucket	
		return (LinkedList.searchElement(BucketSet[bucketIndex], key));	//return frequency of entry
	}
	
	public double getAverage()		//get average number of nodes 
	{	
		int words = 0;

		for (int i = 0;i < Buckets; i++) 	//get total nodes in hashtable
				 {
				 	words = LinkedList.getSize(BucketSet[i]) + words;
				 }

		return words*1.0/this.Buckets;	//return average
	}
    
	public int getMax()	//get maximum nodes in a bucket 
	{
		int max = LinkedList.getSize(BucketSet[0]);   //assume 1st bucket has maximum number of nodes

		for (int i = 0;i < Buckets; i++) 	//iterate and find the bucket with most nodes
				 {	
				 	int words = LinkedList.getSize(BucketSet[i]);
				 	if(words > max)
				 		max = words;
				 }

				 return max;
	}

	public int getMin()	//get minimum nodes in a bucket 
	{
		int min = LinkedList.getSize(BucketSet[0]);   //assume 1st bucket has minimum number of nodes

		for (int i = 0;i < Buckets; i++) 	//iterate and find the bucket with most nodes
				 {	
				 	int words = LinkedList.getSize(BucketSet[i]);
				 	if(words < min)
				 		min = words;
				 }

				 return min;
	}

	public double getStandardDeviation()	//get standard deviation of nodes in hashtable 
	{
		double sd = 0;
		double sum = 0;

		double avg = getAverage();		//get average

		for (int i = 0;i < Buckets; i++) 	//calculate variance
				 {	
				 	int words = LinkedList.getSize(BucketSet[i]);
				 	sum = sum + Math.pow((avg - words) , 2);
				 }
		sd = Math.pow(sum/Buckets , 0.5);	//get standard deviation from variance

		return sd;
	}

}// end HashTableImp 
