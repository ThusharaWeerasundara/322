
class HashTableImp2 extends HashTableImp //to give hash multiplication methods extends parent class
{

	public HashTableImp2(int buckets) 	//constructor
		{	
			 super(buckets);
			 
		// create a open hash table with given number of buckets 
	    
		}


	public int hashFunction(String key) 	//method overiding used to make hashmultiplication method
	    { 
	        int w = 32; //assume word size is 32bits 
	        long a = (long)(Math.pow(2,w) + Math.pow(2,w-1))/2 + 1;

	        int r = (int)(Math.log(Buckets) / Math.log(2));		//take r such buckets = 2^r

	        int k = (int)(asciValue(key)); 

	        int hashvalue = (int)(((a*k)%(long)Math.pow(2,32)) >> (w-r));	//h(k) = (a*k)mod(2^32)rhs(w-r)

	        return Math.abs(hashvalue); 
	    }  
}