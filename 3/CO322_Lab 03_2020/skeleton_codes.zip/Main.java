


public class Main
{
	public static void main(String[] args) throws Exception
	{
	   Support obj = new Support();
	   HashTableImp buckets;
	   HashTableImp2 buckets2;

	   obj.getDataFromDivisionHashTable("sample-text1.txt");
	   obj.getDataFromMultiplicationHashTable("sample-text1.txt");
	

		HashTableImp bucketstest = obj.readFile("sample-text1.txt",47);
		HashTableImp2 bucketstest2 = obj.readFile2("sample-text1.txt",128);;
		
		//getData("1.txt");
		//System.out.println(buckets2.search("the"));

		System.out.println(bucketstest.search("on"));
		System.out.println(bucketstest2.search("on"));
		//System.out.println(((Math.pow(2,32) + Math.pow(2,31))/2 + 1) % 2);
		
	}








}