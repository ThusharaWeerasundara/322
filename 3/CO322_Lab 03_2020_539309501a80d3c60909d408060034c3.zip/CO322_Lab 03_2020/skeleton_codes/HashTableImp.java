/*********************************************
 
	* CO322: Data structures and algorithms
 
	* Implementation of the hashTable
 *********************************************/


class HashTableImp implements HashTable {

    

	/* Put your code here */

    

	public HashTableImp(int buckets) {
	
	// create a open hash table with given number of buckets 
    
	}

    



}// end HashTableImp 
