E/16/388
CO322 lab 1

1) For python runtimes graphs
	fib.py displays grahical representation of runtimes for python.


2)For Java runtime graphs
	1st run Fib.java, then run javaplot.py
Fib.java creates JavaRecursionTime.csv and JavaIteration.csv files to store runtimes. javaplot.py uses those 2 files and graph values in them

3)To compare runtimes of both languages, run Plotall.py. It graphs 4 implementations in a single graph

4)e16388answers.pdf contains answers for the eassay questions

5)Other png files have plots of implementations